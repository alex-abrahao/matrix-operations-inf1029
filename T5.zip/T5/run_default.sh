echo "Running with default args"
# ./matrix_lib_test 5.0 1024 1024 1024 1024 1 8 floats_1024_1.0.dat floats_1024_5.0.dat result1.dat result2.dat
./matrix_lib_test 5.0 8 16 16 8 2 8 floats_128.dat floats_128.dat result1.dat result2.dat
